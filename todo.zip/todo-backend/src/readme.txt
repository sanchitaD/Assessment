Create a Test Assessment as an "Executable File" so that it will be easier for you to explain at the time 
of Interview. 

Also make sure you to send the Test in Zip format and can be downloaded (Google Drive/Github,etc)

“ Build a ToDo application with option to 
1) add/delete 
2) mark it as completed. 
3) Also you should be to show pending and completed tasks.

Front End  : Angularjs / Javascript / Html / Css3

Middleware : Spring boot / Spring

Back end   : any in memory DB ex. H2 , MongoDB etc.”